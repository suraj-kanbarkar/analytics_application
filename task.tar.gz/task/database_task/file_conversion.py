
import csv

leads_data = open('/home/suraj/Desktop/MySQL/data/LEADS.txt', 'w')
mst_data=open('/home/suraj/Desktop/MySQL/data/MST.txt', 'w')

# Create LEADS.txt
with open('/home/suraj/Desktop/MySQL/data/LEADS.csv',"rt") as leads_file:
	for row in leads_file:
    		leads_data.write(row)

# Create MST.txt
with open('/home/suraj/Desktop/MySQL/data/MST.csv',"rt") as mst_file:
	for row in mst_file:
    		mst_data.write(row)


