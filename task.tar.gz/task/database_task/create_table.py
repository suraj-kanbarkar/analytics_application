
import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="fycore",
  database="neumath"
)

mycursor = mydb.cursor()

mycursor.execute("CREATE TABLE lead(ID INT AUTO_INCREMENT PRIMARY KEY, lead_phone varchar(30), lead_state VARCHAR(10), ddc_entered_on VARCHAR(20), spaid_date VARCHAR(20), outsource_agency VARCHAR(20), teacher_state VARCHAR(20),a VARCHAR(1),b VARCHAR(1),c VARCHAR(1))")


mycursor.execute("CREATE TABLE mst(ID INT AUTO_INCREMENT PRIMARY KEY, Phone VARCHAR(30), RID VARCHAR(6), Disposition VARCHAR(30), CallBack_DateTime VARCHAR(20), FinalStatus VARCHAR(7))")

#mycursor.commit()

#mycursor.close()


